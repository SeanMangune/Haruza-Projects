import sql from 'mssql'


export const dbConfig = {
  user: "lemon",               // your SQL login
  password: "lemon",           // your SQL password
  server: "192.168.1.119", // IP + instance name
  database: "MasterDB",
  options: {
    encrypt: false,               // disable SSL for local network
    trustServerCertificate: true  // accept self-signed certs
  }
};
