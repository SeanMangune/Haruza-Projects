// @ts-nocheck
import sql from 'mssql'
import axios from 'axios'
import express from 'express'
import cors from 'cors'

import { dbConfig } from './dbConfig.js'

// EXPRESS APP SETUP
const app = express()
app.use(cors())
app.use(express.json())
 

//DATABASE CONNECTION
let pool;

(async function ensureOrderNumberSequenceAndDefault() {
    // No-op placeholder until pool is set; real execution happens after connecting
})();

(async () => {
  try {
    pool = await sql.connect(dbConfig);
    console.log("✅ Connected to SQL Server (Windows Auth)");

        // Ensure sequence and default constraint for TempOrders.orders_ordernumber
        try {
            const tsql = `
            DECLARE @start BIGINT;
            SELECT @start = CASE 
                                                 WHEN MAX(orders_ordernumber) IS NULL OR MAX(orders_ordernumber) < 999 THEN 1000 
                                                 ELSE MAX(orders_ordernumber) + 1 
                                             END
            FROM dbo.TempOrders WITH (NOLOCK);

            IF NOT EXISTS (
                SELECT 1 FROM sys.sequences s 
                WHERE s.name = N'Orders_OrderNumber_Seq' AND SCHEMA_NAME(s.schema_id) = N'dbo'
            )
            BEGIN
                DECLARE @create NVARCHAR(MAX) = N'CREATE SEQUENCE dbo.Orders_OrderNumber_Seq AS BIGINT START WITH ' + CAST(@start AS NVARCHAR(50)) + N' INCREMENT BY 1 CACHE 50';
                EXEC(@create);
            END
            ELSE
            BEGIN
                DECLARE @restart NVARCHAR(MAX) = N'ALTER SEQUENCE dbo.Orders_OrderNumber_Seq RESTART WITH ' + CAST(@start AS NVARCHAR(50));
                EXEC(@restart);
            END

            -- Drop existing default constraint for TempOrders.orders_ordernumber, if any
            DECLARE @dfName sysname;
            SELECT @dfName = dc.name
            FROM sys.default_constraints dc
            INNER JOIN sys.columns c ON c.default_object_id = dc.object_id
            INNER JOIN sys.tables t ON t.object_id = c.object_id
            WHERE t.name = N'TempOrders' 
                AND SCHEMA_NAME(t.schema_id) = N'dbo' 
                AND c.name = N'orders_ordernumber';

            IF @dfName IS NOT NULL
            BEGIN
                EXEC(N'ALTER TABLE dbo.TempOrders DROP CONSTRAINT ' + QUOTENAME(@dfName));
            END

            -- Add default constraint to use the sequence
            IF NOT EXISTS (
                SELECT 1 
                FROM sys.default_constraints dc 
                INNER JOIN sys.columns c ON c.default_object_id = dc.object_id
                INNER JOIN sys.tables t ON t.object_id = c.object_id
                WHERE t.name = N'TempOrders' 
                    AND SCHEMA_NAME(t.schema_id) = N'dbo' 
                    AND c.name = N'orders_ordernumber'
            )
            BEGIN
                EXEC(N'ALTER TABLE dbo.TempOrders ADD CONSTRAINT DF_TempOrders_orders_ordernumber DEFAULT (NEXT VALUE FOR dbo.Orders_OrderNumber_Seq) FOR orders_ordernumber');
            END`;

            await pool.request().batch(tsql);
            console.log('🔢 Ensured sequence dbo.Orders_OrderNumber_Seq and default on TempOrders.orders_ordernumber');
        } catch (seqErr) {
            console.error('⚠️ Failed to ensure order number sequence/default:', seqErr.message);
        }

    // Start server only after DB connection is established
    app.listen(3000, () => {
      console.log('Server is running on port 3000');

      // Perform initial check for temp orders
      checkForNewTempOrders();

      // Start automatic checking for new temp orders every 3 seconds
      setInterval(checkForNewTempOrders, 3000); // 3 seconds

      // Perform initial check for menu items
      checkForNewMenuItems();

      // Start automatic checking for new menu items every 3 seconds
      setInterval(checkForNewMenuItems, 3000); // 3 seconds

      // Perform initial check for product categories
      checkForNewProductCategories();

      // Start automatic checking for product categories every 3 seconds
      setInterval(checkForNewProductCategories, 3000); // 3 seconds

      // Perform initial check for products
      checkForNewProducts();

      // Start automatic checking for products every 3 seconds
      setInterval(checkForNewProducts, 3000); // 3 seconds

      // Perform initial check for menu addons
      checkForNewMenuAddons();

      // Start automatic checking for menu addons every 3 seconds
      setInterval(checkForNewMenuAddons, 3000); // 3 seconds

      // Perform initial check for menu compositions
      checkForNewMenuCompositions();

      // Start automatic checking for menu compositions every 3 seconds
      setInterval(checkForNewMenuCompositions, 3000); // 3 seconds

      // Perform initial check for temp order details
        checkForNewTempOrderDetails();

      //Start automatic checking for temp order details every 3 seconds
        setInterval(checkForNewTempOrderDetails, 3000); // 3 seconds

      // Perform initial check for temp order compositions
      checkForNewTempOrderCompositions();

      // Start automatic checking for temp order compositions every 3 seconds
      setInterval(checkForNewTempOrderCompositions, 3000); // 3 seconds

      // Perform initial check for menu selling prices
      checkForNewMenuSellingPrices();

      // Start automatic checking for menu selling prices every 3 seconds
      setInterval(checkForNewMenuSellingPrices, 3000); // 3 seconds

    
    });
  } catch (err) {
    console.error("❌ Database connection failed:", err);
    process.exit(1);
  }
})();



//!! @@Functions Start here 

// Helper function to format date as "YYYY-MM-DD HH:mm:ss.SSSS"
function formatDate(date) {
    const pad = (num, size = 2) => num.toString().padStart(size, '0');
    const year = date.getFullYear();
    const month = pad(date.getMonth() + 1);
    const day = pad(date.getDate());
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    const seconds = pad(date.getSeconds());
    const milliseconds = pad(date.getMilliseconds(), 4); // 4 digits as per user request, though usually 3 digits

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${milliseconds}`;
}

const api = axios.create({
    baseURL: 'https://api.1teqproviders.com',
    headers: {
        "Content-Type": "application/json",
    }
})


let knownTempOrderIds = new Set(); // To track known temp order IDs
let knownMenuIds = new Set(); // To track known menu IDs
let knownTempOrderDetailIds = new Set(); // To track synced/attempted temp order detail IDs

// Helper function for robust value comparison
function areValuesEqual(dbVal, apiVal) {
    // Handle null/undefined cases
    if (dbVal === null || dbVal === undefined) dbVal = '';
    if (apiVal === null || apiVal === undefined) apiVal = '';
    
    // Handle boolean comparisons
    if (typeof dbVal === 'boolean' || typeof apiVal === 'boolean') {
        const dbBool = dbVal === true || dbVal === 1 || dbVal === '1';
        const apiBool = apiVal === true || apiVal === 1 || apiVal === '1';
        return dbBool === apiBool;
    }
    
    // Handle numeric comparisons (including string numbers like "9" vs "9.00")
    const dbNum = parseFloat(dbVal);
    const apiNum = parseFloat(apiVal);
    if (!isNaN(dbNum) && !isNaN(apiNum)) {
        return Math.abs(dbNum - apiNum) < 0.0001; // Small tolerance for floating point
    }
    
    // Handle date/datetime comparisons (ISO vs SQL format)
    // Try to parse both values as dates
    const dbDate = new Date(dbVal);
    const apiDate = new Date(apiVal);
    if (!isNaN(dbDate.getTime()) && !isNaN(apiDate.getTime())) {
        // Compare timestamps (ignoring milliseconds for SQL datetime precision)
        return Math.abs(dbDate.getTime() - apiDate.getTime()) < 1000;
    }
    
    // Default string comparison (trim whitespace)
    return String(dbVal).trim() === String(apiVal).trim();
}

// Helper function to get all fields from DB item (for comprehensive syncing)
function getAllFieldsFromDbItem(item) {
    const fields = {};
    for (const key in item) {
        if (item.hasOwnProperty(key)) {
            fields[key] = item[key];
        }
    }
    return fields;
}

// Function to process new temp orders
async function processNewOrders(newOrders) {
    for (const order of newOrders) {
        try {
            // Format dates for DB and API
            const formattedOrderDate = formatDate(new Date(order.orders_datetime));
            const formattedSyncDate = formatDate(new Date());

            // First, insert the order into the local database
            // Always use DB sequence for orders_ordernumber; do not use incoming order.orders_ordernumber
            const req = pool.request()
                .input('orders_datetime', sql.NVarChar, order.orders_datetime)
                .input('isOrderSelected', sql.Int, order.isOrderSelected)
                .input('OrderSelectedBy', sql.NVarChar, order.OrderSelectedBy)
                .input('OrderSelectedTerminal', sql.NVarChar, order.OrderSelectedTerminal)
                .input('orders_tablenumber', sql.Int, order.orders_tablenumber)
                .input('IsLocalSynced', sql.Int, 1)
                .input('localSyncDatetime', sql.NVarChar, formattedSyncDate);

            const columns = [];
            const values = [];
            // Intentionally exclude orders_ordernumber so default (sequence) generates it
            columns.push('orders_datetime', 'isOrderSelected', 'OrderSelectedBy', 'OrderSelectedTerminal', 'orders_tablenumber', 'IsLocalSynced', 'localSyncDatetime');
            values.push('@orders_datetime', '@isOrderSelected', '@OrderSelectedBy', '@OrderSelectedTerminal', '@orders_tablenumber', '@IsLocalSynced', '@localSyncDatetime');

            const insertSql = `INSERT INTO dbo.TempOrders (${columns.join(', ')}) VALUES (${values.join(', ')})`;
            await req.query(insertSql);

            // If DB insert succeeds, update the temp order on the API to mark as locally synced
            try {
                await api.patch(`/api/temp-orders/${order.orders_id}`, {
                    IsLocalSynced: 1,
                    localSyncDatetime: formattedSyncDate
                });
            } catch (apiError) {
                console.error(`❌ API update failed for order ${order.orders_id}:`, apiError.response?.data || apiError.message);
            }

            console.log(`✅ Processed and synced order ${order.orders_id}`);
            knownTempOrderIds.add(order.orders_id);
        } catch (error) {
            console.error(`❌ Error processing order ${order.orders_id}:`, error.message);
        }
    }
}

// Function to check for new temp orders
async function checkForNewTempOrders() {
    try {
        const response = await api.get('/api/temp-orders?isLocalSynced=0');
        const tempOrders = response.data;

        const newOrders = tempOrders.filter(order => order.isLocalSynced === 0 && !knownTempOrderIds.has(order.orders_id));

        if (newOrders.length > 0) {
            console.log(`🆕 Found ${newOrders.length} new temp orders`);
            await processNewOrders(newOrders);
        } else {
            console.log('✅ No new temp orders found');
        }
    } catch (error) {
        console.error('❌ Error checking for new temp orders:', error.message);
    }
}


// Function to check for new menu items and sync from db to api
async function checkForNewMenuItems() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.Menu');
        const dbMenu = dbResult.recordset;

        const apiResponse = await api.get('/api/menu');
        const apiMenu = apiResponse.data;

        const dbIds = new Set(dbMenu.map(item => parseInt(item.ID)));
        const apiIds = new Set(apiMenu.map(item => parseInt(item.ID)));

        // New in DB, post to API
        const newInDb = dbMenu.filter(item => !apiIds.has(parseInt(item.ID)));
        for (const item of newInDb) {
            try {
                // Get ALL fields from DB item dynamically
                const apiItem = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        
                        // Convert booleans
                        if (['isavailable', 'withtax', 'withceilingaddonweight', 'selectpushproducts', 
                             'isActive', 'printlabel', 'getgro', 'getmanager'].includes(key)) {
                            value = value === 1;
                        } 
                        // Convert numbers to strings for specific fields
                        else if (typeof value === 'number' && ['ID', 'categoryid', 'unitcost', 'stocks', 
                                 'taxpercent', 'ceilingaddonweight', 'pushproductcount', 'headcount', 
                                 'multiplier', 'menuimagesize', 'iskioskavailable'].includes(key)) {
                            value = value.toString();
                        }
                        
                        apiItem[key] = value;
                    }
                }
                
                await api.post('/api/menu', apiItem);
                console.log(`✅ Posted new menu item ${item.ID} to API`);
            } catch (err) {
                console.error(`❌ Failed to post item ${item.ID}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbMenu.filter(item => apiIds.has(parseInt(item.ID)));
        for (const item of existingInBoth) {
            try {
                // Get ALL fields from DB and build comprehensive API object
                const apiItemFromDb = {};
                
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        
                        // Handle specific conversions based on field type
                        if (['isavailable', 'withtax', 'withceilingaddonweight', 'selectpushproducts', 
                             'isActive', 'printlabel', 'getgro', 'getmanager'].includes(key)) {
                            value = value === 1;
                        } 
                        else if (typeof value === 'number' && ['ID', 'categoryid', 'unitcost', 'stocks', 
                                 'taxpercent', 'ceilingaddonweight', 'pushproductcount', 'headcount', 
                                 'multiplier', 'menuimagesize', 'iskioskavailable'].includes(key)) {
                            value = value.toString();
                        }
                        
                        apiItemFromDb[key] = value;
                    }
                }

                // Find corresponding API item
                const apiItem = apiMenu.find(a => parseInt(a.ID) === parseInt(item.ID));
                
                if (!apiItem) continue;

                // Check if any field differs
                let hasChanges = false;
                const changes = [];
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        changes.push(`${field}: DB="${apiItemFromDb[field]}" vs API="${apiItem[field]}"`);
                        hasChanges = true;
                    }
                }

                if (hasChanges) {
                    console.log(`📝 Changes detected in menu item ${item.ID}:`, changes);
                    await api.patch(`/api/menu/${item.ID}`, apiItemFromDb);
                    console.log(`✅ Updated menu item ${item.ID} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update menu item ${item.ID}:`, err.response?.data || err.message);
            }
        }

        if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated menu items to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing menu items for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new menu items:', error.message);
    }
}


// Function to check for new product categories and sync from db to api
async function checkForNewProductCategories() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.ProductCategory');
        const dbCategories = dbResult.recordset;

        const apiResponse = await api.get('/api/product-categories');
        const apiCategories = apiResponse.data;

        const dbIds = new Set(dbCategories.map(item => parseInt(item.prodcat_id)));
        const apiIds = new Set(apiCategories.map(item => parseInt(item.prodcat_id)));

        // New in DB, post to API
        const newInDb = dbCategories.filter(item => !apiIds.has(parseInt(item.prodcat_id)));
        for (const item of newInDb) {
            try {
                const apiItem = getAllFieldsFromDbItem(item);
                await api.post('/api/product-categories', apiItem);
                console.log(`✅ Posted new product category ${item.prodcat_id} to API`);
                apiIds.add(parseInt(item.prodcat_id));
            } catch (err) {
                console.error(`❌ Failed to post product category ${item.prodcat_id}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbCategories.filter(item => apiIds.has(parseInt(item.prodcat_id)));
        for (const item of existingInBoth) {
            try {
                const apiItemFromDb = getAllFieldsFromDbItem(item);

                const apiItem = apiCategories.find(a => parseInt(a.prodcat_id) === parseInt(item.prodcat_id));
                if (!apiItem) continue;

                let hasChanges = false;
                const changes = [];
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        changes.push(`${field}: DB="${apiItemFromDb[field]}" vs API="${apiItem[field]}"`);
                        hasChanges = true;
                    }
                }

                if (hasChanges) {
                    console.log(`📝 Changes detected in product category ${item.prodcat_id}:`, changes);
                    await api.patch(`/api/product-categories/${item.prodcat_id}`, apiItemFromDb);
                    console.log(`✅ Updated product category ${item.prodcat_id} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update product category ${item.prodcat_id}:`, err.response?.data || err.message);
            }
        }

        if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated product categories to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing product categories for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new product categories:', error.message);
    }
}

// Function to check for new products and sync from db to api
async function checkForNewProducts() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.Products');
        const dbProducts = dbResult.recordset;

        const apiResponse = await api.get('/api/products');
        const apiProducts = apiResponse.data;

        const dbIds = new Set(dbProducts.map(item => parseInt(item.ID)));
        const apiIds = new Set(apiProducts.map(item => parseInt(item.ID)));

        // New in DB, post to API
        const newInDb = dbProducts.filter(item => !apiIds.has(parseInt(item.ID)));
        for (const item of newInDb) {
            try {
                const apiItem = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (key === 'prodlst_istaxable') {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'prodlst_taxpercentage'].includes(key)) {
                            value = value.toString();
                        }
                        apiItem[key] = value;
                    }
                }
                await api.post('/api/products', apiItem);
                console.log(`✅ Posted new product ${item.ID} to API`);
            } catch (err) {
                console.error(`❌ Failed to post product ${item.ID}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbProducts.filter(item => apiIds.has(parseInt(item.ID)));
        for (const item of existingInBoth) {
            try {
                const apiItemFromDb = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (key === 'prodlst_istaxable') {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'prodlst_taxpercentage'].includes(key)) {
                            value = value.toString();
                        }
                        apiItemFromDb[key] = value;
                    }
                }

                const apiItem = apiProducts.find(a => parseInt(a.ID) === parseInt(item.ID));
                if (!apiItem) continue;

                let hasChanges = false;
                const changes = [];
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        changes.push(`${field}: DB="${apiItemFromDb[field]}" vs API="${apiItem[field]}"`);
                        hasChanges = true;
                    }
                }

                if (hasChanges) {
                    console.log(`📝 Changes detected in product ${item.ID}:`, changes);
                    await api.patch(`/api/products/${item.ID}`, apiItemFromDb);
                    console.log(`✅ Updated product ${item.ID} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update product ${item.ID}:`, err.response?.data || err.message);
            }
        }

        if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated products to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing products for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new products:', error.message);
    }
}


// Function to check for new menu addons and sync from db to api
async function checkForNewMenuAddons() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.MenuAddOn');
        const dbMenuAddons = dbResult.recordset;

        const apiResponse = await api.get('/api/menu-addons');
        const apiMenuAddons = apiResponse.data;

        const dbIds = new Set(dbMenuAddons.map(item => parseInt(item.ID)));
        const apiIds = new Set(apiMenuAddons.map(item => parseInt(item.ID)));

        // New in DB, post to API
        const newInDb = dbMenuAddons.filter(item => !apiIds.has(parseInt(item.ID)));
        for (const item of newInDb) {
            try {
                const apiItem = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (key === 'checkceilingweight') {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'menuid', 'amount'].includes(key)) {
                            value = value.toString();
                        }
                        apiItem[key] = value;
                    }
                }
                await api.post('/api/menu-addons', apiItem);
                console.log(`✅ Posted new menu addon ${item.ID} to API`);
            } catch (err) {
                console.error(`❌ Failed to post menu addon ${item.ID}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbMenuAddons.filter(item => apiIds.has(parseInt(item.ID)));
        for (const item of existingInBoth) {
            try {
                const apiItemFromDb = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (key === 'checkceilingweight') {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'menuid', 'amount'].includes(key)) {
                            value = value.toString();
                        }
                        apiItemFromDb[key] = value;
                    }
                }

                const apiItem = apiMenuAddons.find(a => parseInt(a.ID) === parseInt(item.ID));
                if (!apiItem) continue;

                let hasChanges = false;
                const changes = [];
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        changes.push(`${field}: DB="${apiItemFromDb[field]}" vs API="${apiItem[field]}"`);
                        hasChanges = true;
                    }
                }

                if (hasChanges) {
                    console.log(`📝 Changes detected in menu addon ${item.ID}:`, changes);
                    await api.patch(`/api/menu-addons/${item.ID}`, apiItemFromDb);
                    console.log(`✅ Updated menu addon ${item.ID} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update menu addon ${item.ID}:`, err.response?.data || err.message);
            }
        }

        if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated menu addons to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing menu addons for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new menu addons:', error.message);
    }
}

// Function to check for new menu compositions and sync from db to api
async function checkForNewMenuCompositions() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.MenuCompositions');
        const dbMenuCompositions = dbResult.recordset;

        const apiResponse = await api.get('/api/menu-compositions');
        const apiMenuCompositions = apiResponse.data;

        const dbIds = new Set(dbMenuCompositions.map(item => parseInt(item.ID)));
        const apiIds = new Set(apiMenuCompositions.map(item => parseInt(item.ID)));

        // New in DB, post to API
        const newInDb = dbMenuCompositions.filter(item => !apiIds.has(parseInt(item.ID)));
        for (const item of newInDb) {
            try {
                const apiItem = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (['display', 'addondinein', 'addontakeout', 'allowmodify', 'adjustprice'].includes(key)) {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'menuid'].includes(key)) {
                            value = value.toString();
                        }
                        apiItem[key] = value;
                    }
                }
                await api.post('/api/menu-compositions', apiItem);
                console.log(`✅ Posted new menu composition ${item.ID} to API`);
            } catch (err) {
                console.error(`❌ Failed to post menu composition ${item.ID}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbMenuCompositions.filter(item => apiIds.has(parseInt(item.ID)));
        for (const item of existingInBoth) {
            try {
                const apiItemFromDb = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        if (['display', 'addondinein', 'addontakeout', 'allowmodify', 'adjustprice'].includes(key)) {
                            value = value === 1;
                        } else if (typeof value === 'number' && ['ID', 'menuid'].includes(key)) {
                            value = value.toString();
                        }
                        apiItemFromDb[key] = value;
                    }
                }

                const apiItem = apiMenuCompositions.find(a => parseInt(a.ID) === parseInt(item.ID));
                if (!apiItem) continue;

                let hasChanges = false;
                const changes = [];
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        changes.push(`${field}: DB="${apiItemFromDb[field]}" vs API="${apiItem[field]}"`);
                        hasChanges = true;
                    }
                }

                if (hasChanges) {
                    console.log(`📝 Changes detected in menu composition ${item.ID}:`, changes);
                    await api.patch(`/api/menu-compositions/${item.ID}`, apiItemFromDb);
                    console.log(`✅ Updated menu composition ${item.ID} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update menu composition ${item.ID}:`, err.response?.data || err.message);
            }
        }

        if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated menu compositions to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing menu compositions for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new menu compositions:', error.message);
    }
}


// Function to check for new temp order details and sync in both api and db
async function checkForNewTempOrderDetails() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.TempOrderDetails');
        const dbTempOrderDetails = dbResult.recordset;

        const apiResponse = await api.get('/api/temp-order-details');
        const apiTempOrderDetails = apiResponse.data;

    // Normalize values to string to avoid mismatches between number vs string
    const norm = (v) => v === null || v === undefined ? '' : String(v);
    // Track by ordernumber because API duplicate errors reference PRIMARY on ordernumber
    const dbOrderNos = new Set(dbTempOrderDetails.map(item => norm(item.orddet_ordernumber)));
    const apiOrderNos = new Set(apiTempOrderDetails.map(item => norm(item.orddet_ordernumber)));

        // New in DB, post to API
        const newInDb = dbTempOrderDetails.filter(item => {
            const ordNo = norm(item.orddet_ordernumber);
            return ordNo && !apiOrderNos.has(ordNo) && !knownTempOrderDetailIds.has(ordNo);
        });
        for (const item of newInDb) {
            try {
                const apiItem = {
                    orddet_id: item.orddet_id?.toString() || '',
                    orddet_ordernumber: item.orddet_ordernumber,
                    orddet_menuid: item.orddet_menuid,
                    orddet_menucode: item.orddet_menucode,
                    orddet_menuname: item.orddet_menuname,
                    orddet_quantity: item.orddet_quantity,
                    orddet_selling: item.orddet_selling,
                    orddet_totalamount: item.orddet_totalamount,
                    orddet_isdinein: item.orddet_isdinein,
                    orddet_datetime: formatDate(new Date(item.orddet_datetime))
                };
                await api.post('/api/temp-order-details', apiItem);
                console.log(`✅ Posted new temp order detail with ordernumber ${item.orddet_ordernumber} to API`);
                knownTempOrderDetailIds.add(norm(item.orddet_ordernumber));
            } catch (err) {
                const ordStr = norm(item.orddet_ordernumber);
                const details = err.response?.data || err.message;
                console.error(`❌ Failed to post temp order detail with ordernumber ${ordStr}:`, details);
                // If duplicate key, treat as already present to avoid retry loops
                if (typeof details === 'object') {
                    const msg = (details.details || details.error || '').toString().toLowerCase();
                    if (msg.includes('duplicate') || msg.includes('primary')) {
                        knownTempOrderDetailIds.add(ordStr);
                    }
                } else if (typeof details === 'string') {
                    const msg = details.toLowerCase();
                    if (msg.includes('duplicate') || msg.includes('primary')) {
                        knownTempOrderDetailIds.add(ordStr);
                    }
                }
            }
        }

        // New in API, insert to DB
        const newInApi = apiTempOrderDetails.filter(item => !dbOrderNos.has(norm(item.orddet_ordernumber)));
        for (const item of newInApi) {
            try {
                await pool.request()
                    .input('orddet_ordernumber', sql.Numeric(18, 0), item.orddet_ordernumber)
                    .input('orddet_menuid', sql.NVarChar(50), item.orddet_menuid)
                    .input('orddet_menucode', sql.NVarChar(50), item.orddet_menucode)
                    .input('orddet_menuname', sql.NVarChar(100), item.orddet_menuname)
                    .input('orddet_quantity', sql.Money, item.orddet_quantity)
                    .input('orddet_selling', sql.Money, item.orddet_selling)
                    .input('orddet_totalamount', sql.Money, item.orddet_totalamount)
                    .input('orddet_isdinein', sql.Numeric(18, 0), item.orddet_isdinein)
                    .input('orddet_datetime', sql.NVarChar, item.orddet_datetime)
                    .query(`INSERT INTO dbo.TempOrderDetails
                        (orddet_ordernumber, orddet_menuid, orddet_menucode, orddet_menuname, orddet_quantity, orddet_selling, orddet_totalamount, orddet_isdinein, orddet_datetime)
                        VALUES
                        (@orddet_ordernumber, @orddet_menuid, @orddet_menucode, @orddet_menuname, @orddet_quantity, @orddet_selling, @orddet_totalamount, @orddet_isdinein, @orddet_datetime)`);
                console.log(`✅ Inserted new temp order detail with ordernumber ${item.orddet_ordernumber} to DB`);
            } catch (err) {
                console.error(`❌ Failed to insert temp order detail with ordernumber ${item.orddet_ordernumber}:`, err.message);
            }
        }

        if (newInDb.length === 0 && newInApi.length === 0) {
            console.log('✅ No new temp order details to sync');
        }
    } catch (error) {
        console.error('❌ Error checking for new temp order details:', error.message);
    }
}
// Function to check for new temp order compositions and sync in both api and db
async function checkForNewTempOrderCompositions() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.TempOrderComposition');
        const dbTempOrderCompositions = dbResult.recordset;

        const apiResponse = await api.get('/api/temp-order-compositions');
        const apiTempOrderCompositions = apiResponse.data;

        const dbIds = new Set(dbTempOrderCompositions.map(item => parseInt(item.orddet_id)));
        const apiIds = new Set(apiTempOrderCompositions.map(item => parseInt(item.orddet_id)));

        // New in DB, post to API
        const newInDb = dbTempOrderCompositions.filter(item => !apiIds.has(parseInt(item.orddet_id)));
        for (const item of newInDb) {
            try {
                const apiItem = {
                    ID: item.ID?.toString() || '',
                    menuid: item.menuid,
                    orddet_id: item.orddet_id,
                    menucode: item.menucode,
                    ordernumber: item.ordernumber,
                    productcode: item.productcode,
                    quantity: item.quantity,
                    totalamount: item.totalamount,
                    menudescription: item.menudescription,
                    orders_datetime: item.orders_datetime ? item.orders_datetime.toISOString() : null
                };
                await api.post('/api/temp-order-compositions', apiItem);
                console.log(`✅ Posted new temp order composition ${item.orddet_id} to API`);
            } catch (err) {
                console.error(`❌ Failed to post temp order composition ${item.orddet_id}:`, err.response?.data || err.message);
            }
        }

        // New in API, insert to DB
        const newInApi = apiTempOrderCompositions.filter(item => !dbIds.has(parseInt(item.orddet_id)));
        for (const item of newInApi) {
            try {
                await pool.request()
                    .input('menuid', sql.NVarChar(50), item.menuid)
                    .input('orddet_id', sql.Int, item.orddet_id)
                    .input('menucode', sql.NVarChar(50), item.menucode)
                    .input('ordernumber', sql.Int, item.ordernumber)
                    .input('productcode', sql.NVarChar(50), item.productcode)
                    .input('quantity', sql.Decimal(18, 2), item.quantity)
                    .input('totalamount', sql.Decimal(18, 2), item.totalamount)
                    .input('menudescription', sql.NVarChar(100), item.menudescription)
                    .input('orders_datetime', sql.NVarChar, item.orders_datetime)
                    .query(`INSERT INTO dbo.TempOrderComposition
                        (menuid, orddet_id, menucode, ordernumber, productcode, quantity, totalamount, menudescription, orders_datetime)
                        VALUES
                        (@menuid, @orddet_id, @menucode, @ordernumber, @productcode, @quantity, @totalamount, @menudescription, @orders_datetime)`);
                console.log(`✅ Inserted new temp order composition ${item.orddet_id} to DB`);
            } catch (err) {
                console.error(`❌ Failed to insert temp order composition ${item.orddet_id}:`, err.message);
            }
        }

        if (newInDb.length === 0 && newInApi.length === 0) {
            console.log('✅ No new temp order compositions to sync');
        }
    } catch (error) {
        console.error('❌ Error checking for new temp order compositions:', error.message);
    }
}

// Function to check for new menu selling prices and sync from db to api
async function checkForNewMenuSellingPrices() {
    try {
        const dbResult = await pool.request().query('SELECT * FROM dbo.MenuSellingPrice');
        const dbMenuSellingPrices = dbResult.recordset;

        const apiResponse = await api.get('/api/menu-selling-prices');
        const apiMenuSellingPrices = apiResponse.data;

        const dbIds = new Set(dbMenuSellingPrices.map(item => parseInt(item.id)));
        const apiIds = new Set(apiMenuSellingPrices.map(item => parseInt(item.id)));

        // New in DB, post to API
        const newInDb = dbMenuSellingPrices.filter(item => !apiIds.has(parseInt(item.id)));
        for (const item of newInDb) {
            try {
                const effectivityDateFormatted = item.effectivitydate ? formatDate(new Date(item.effectivitydate)) : null;

                const apiItem = {
                    ...getAllFieldsFromDbItem(item),
                    id: item.id,
                    effectivitydate: effectivityDateFormatted,
                    menuid: item.menuid,
                    selling: item.selling,
                    foreign_selling: item.foreign_selling,
                    taxable: item.taxable === 1,
                    taxpercent: item.taxpercent,
                    isdefault: item.isdefault === 1,
                    allowoverride: item.allowoverride === 1,
                    ratetype: item.ratetype,
                    initialrate: item.initialrate,
                    initialtime: item.initialtime,
                    rateperhour: item.rateperhour,
                    applydiccount: item.applydiscount === 1,
                    applyservicecharge: item.applyservicecharge === 1,
                    nonsale: item.nonsale === 1
                };
                await api.post('/api/menu-selling-prices', apiItem);
                console.log(`✅ Posted new menu selling price ${item.id} to API`);
            } catch (err) {
                console.error(`❌ Failed to post menu selling price ${item.id}:`, err.response?.data || err.message);
            }
        }

        // Check for updates in existing items
        const existingInBoth = dbMenuSellingPrices.filter(item => apiIds.has(parseInt(item.id)));
        for (const item of existingInBoth) {
            try {
                const effectivityDateFormatted = item.effectivitydate ? formatDate(new Date(item.effectivitydate)) : null;

                // Build API item from ALL DB fields
                const apiItemFromDb = {};
                for (const key in item) {
                    if (item.hasOwnProperty(key)) {
                        let value = item[key];
                        
                        // Handle specific field conversions
                        if (key === 'effectivitydate') {
                            value = effectivityDateFormatted;
                        } else if (['taxable', 'isdefault', 'allowoverride', 'applydiscount', 'applyservicecharge', 'nonsale'].includes(key)) {
                            value = value === 1;
                        } else if (key === 'applydiscount' && key in item) {
                            // Handle typo in original code (applydiccount vs applydiscount)
                            apiItemFromDb['applydiccount'] = value === 1;
                        }
                        
                        apiItemFromDb[key] = value;
                    }
                }

                // Find corresponding API item
                const apiItem = apiMenuSellingPrices.find(a => parseInt(a.id) === parseInt(item.id));
                if (!apiItem) continue;

                // Check if any field differs
                let hasChanges = false;
                for (const field in apiItemFromDb) {
                    if (!areValuesEqual(apiItemFromDb[field], apiItem[field])) {
                        hasChanges = true;
                        break;
                    }
                }

                if (hasChanges) {
                    console.log(`✅ Checked ${existingInBoth.length} existing menu selling prices for updates`);
                    await api.patch(`/api/menu-selling-prices/${item.id}`, apiItemFromDb);
                    console.log(`✅ Updated menu selling price ${item.id} in API`);
                }
            } catch (err) {
                console.error(`❌ Failed to check/update menu selling price ${item.id}:`, err.response?.data || err.message);
            }
        }

      if (newInDb.length === 0 && existingInBoth.length === 0) {
            console.log('✅ No new or updated product categories to sync');
        } else if (existingInBoth.length > 0) {
            console.log(`✅ Checked ${existingInBoth.length} existing product categories for updates`);
        }
    } catch (error) {
        console.error('❌ Error checking for new menu selling prices:', error.message);
    }
}
//!! @@Functions End here


























//!! @@Routes endpoints Start HERE


// Route to get temp orders data
app.get('/temp-orders', async (req, res) => {
    try {
        const response = await api.get('/api/temp-orders')
        res.json(response.data)
    } catch (error) {
        console.error('Error fetching temp orders:', error)
        res.status(500).json({ error: 'Failed to fetch temp orders' })
    }
})


app.get('/temp-order-details', async (req, res) => {
    try {
        const response = await api.get('/api/temp-order-details')
        res.json(response.data)
    } catch (error) {
        console.error('Error fetching temp orders:', error)
        res.status(500).json({ error: 'Failed to fetch temp orders' })
    }
})


app.get('/temp-order-compositions', async (req, res) => {
    try {
        const response = await api.get('/api/temp-order-details-compositions')
        res.json(response.data)
    } catch (error) {
        console.error('Error fetching temp orders:', error)
        res.status(500).json({ error: 'Failed to fetch temp orders' })
    }
})

// Route to get all data from dbo.Menu table
app.get('/menu', async (req, res) => {
    try {
        if (!pool) {
            return res.status(500).json({ error: 'Database not connected' })
        }
        const result = await pool.request().query('SELECT * FROM dbo.Menu')
        res.json(result.recordset)
    } catch (error) {
        console.error('Error fetching menu data:', error)
        res.status(500).json({ error: 'Failed to fetch menu data' })
    }
})



// Route to sync all menu items individually, ignoring failed posts
app.get('/sync-menu-safe', async (req, res) => {
  try {
    if (!pool) return res.status(500).json({ error: 'Database not connected' })

    const result = await pool.request().query('SELECT * FROM dbo.Menu')
    const menuData = result.recordset
    console.log(`✅ Fetched ${menuData.length} menu items.`)

    const responses = []

    for (const item of menuData) {
      try {
        const apiRes = await api.post('/api/menu', item)
        responses.push({ itemId: item.Id, status: 'success', apiResponse: apiRes.data })
      } catch (err) {
        console.error(`Failed to sync item ${item.Id}:`, err.response?.data || err.message)
        responses.push({ itemId: item.Id, status: 'failed', error: err.response?.data || err.message })
      }
    }

    res.json({ message: 'Menu sync completed', results: responses })
  } catch (error) {
    console.error('Error fetching menu data:', error)
    res.status(500).json({ error: 'Failed to fetch menu data' })
  }
})


//!! @@Route endpoints End HERE